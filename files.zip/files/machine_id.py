import socket
import os

print(f"This machine id is: {socket.gethostname()}")
os.system('pause')